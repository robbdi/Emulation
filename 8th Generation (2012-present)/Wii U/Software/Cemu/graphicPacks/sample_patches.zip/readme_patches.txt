Place patches.txt next to rules.txt of graphics pack
Inside of it, you can have multiple groups (no variables outside of groups, also, give unique names to each of your groups, otherwise their contents will just overwrite each other)
No patch groups from a given patches.txt will even be considered for activation if that graphics pack's rules.txt havent properly loaded in cemu, or if it's not enabled in the normal Graphic Packs GUI
Otherwise, each group will be activated on module load, if that module's "Checksum" (visible from the newly added "View RPL Modules" window in Debug menu) is inside the "moduleMatches" list of that group
Assembler follows "MacOsX" syntax, uses the Keystone library (http://www.keystone-engine.org/) so make sure the keystone.dll is not missing if you want assembled lines to work
All the offsets should be written for a module's defined virtual address, before relocation (as relocation will be applied to all symbols and addresses on the left side, as well as the right side of .ptr entries)
All user defined symbols MUST start with _, and there are a few predefined symbols as well (PC equals the current relocated PC, but you can use builtin . for that as well, and there is a SECTION_XXXX for all the module's sections)
Since 0.5.3.1, code cave support was added because otherwise there really is no place to put additional instructions in
There can be one code cave per group, they aren't shared in any way, and it's size is specified with codeCaveSize integer variable inside the group
If a code cave size on a group is set, any patches for addresses in the range of [0,codeCaveSize) will be placed (and properly relocated) into the cave area, which is dynamically allocated
There is max 983040 bytes available for code caves in total, and the limit for each code cave (remember, max one per group) is 64K, an error will appear if you set it to anything higher (and given value will be clamped to 64K)
CAVE_BEGIN and CAVE_END symbols correspond to the relocated addresses of the current group's cave start and end, respectively (they are undefined if there is no code cave in the group)
To jump to code inside of your code cave, just define a symbol with value = the offset on the left side of the instruction you want to jump to, and then use "ba _symbolName" or "bla _symbolName"

To get more verbose patches.txt loading/assembly messages in your log.txt, add the following lines to your cemuhook.ini:
[Debug]
logPatchAssembly = true
logPatchLoading = true
